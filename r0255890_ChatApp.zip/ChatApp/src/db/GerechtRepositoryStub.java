package db;

import domain.Gerecht;

import java.time.LocalDate;
import java.util.ArrayList;

public class GerechtRepositoryStub implements GerechtRepository {
    private ArrayList<Gerecht> gerechten = new ArrayList<>();

    public GerechtRepositoryStub(){
        Gerecht Noedelsoep = new Gerecht("17/08/2019", "Noedelsoep", 45);
        Gerecht Volauvent = new Gerecht("15/08/2019", "Volauvent" , 60);
        Gerecht Mosselen = new Gerecht("13/08/2019", "Mosselen", 45);
        gerechten.add(Noedelsoep);
        gerechten.add(Volauvent);
        gerechten.add(Mosselen);
    }


    @Override
    public void add(Gerecht gerecht) {
        if(gerecht == null){
            throw new IllegalArgumentException("No dish given!");
        }
        this.gerechten.add(gerecht);
    }

    @Override
    public void delete(Gerecht gerecht) {
        if(gerecht == null){
            throw new IllegalArgumentException("Invalid dish, can't be deleted");
        }
        this.gerechten.remove(gerecht);
    }

    @Override
    public ArrayList<Gerecht> getAll() {
        return this.gerechten;
    }
}
