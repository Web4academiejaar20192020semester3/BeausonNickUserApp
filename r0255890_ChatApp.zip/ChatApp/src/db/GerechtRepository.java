package db;

import domain.Gerecht;

import java.util.ArrayList;

public interface GerechtRepository {

    public abstract void add(Gerecht gerecht);

    public abstract void delete(Gerecht gerecht);

    public abstract ArrayList<Gerecht> getAll();
}
