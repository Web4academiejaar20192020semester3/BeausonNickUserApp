package controller;

import domain.Gerecht;
import domain.GerechtenService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddGerecht extends AsyncRequestHandler {


    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {

        GerechtenService gerechtenService = getGerechtenService();

        String test = request.getParameter("Gerecht");
        System.out.println(test);


        String datum = request.getParameter("datum");
        String naam = request.getParameter("naam");
        int minuten = Integer.parseInt(request.getParameter("minuten"));

        Gerecht gerecht = new Gerecht(datum,naam,minuten);
        gerechtenService.add(gerecht);

        return null;
    }
}
