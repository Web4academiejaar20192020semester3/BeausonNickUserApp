package controller;

import domain.ConversationService;
import domain.GerechtenService;
import domain.PersonService;

public class ControllerFactory {
	
    public RequestHandler getController(String key, PersonService model, GerechtenService gerechtenservice, ConversationService conservationModel) {
        return createHandler(key, model, gerechtenservice,conservationModel);
    }
    
	private RequestHandler createHandler(String handlerName, PersonService model,GerechtenService gerechtenService, ConversationService conversationModel) {
		RequestHandler handler = null;
		try {
			Class<?> handlerClass = Class.forName("controller."+ handlerName);
			Object handlerObject = handlerClass.newInstance();
			handler = (RequestHandler) handlerObject;
	    	handler.setModel(model);
	    	handler.setGerechtenService(gerechtenService);
	    	handler.setConversationModel(conversationModel);
		} catch (Exception e) {
			throw new RuntimeException("Deze pagina bestaat niet!!!!");
		}
		return handler;
	}


}
