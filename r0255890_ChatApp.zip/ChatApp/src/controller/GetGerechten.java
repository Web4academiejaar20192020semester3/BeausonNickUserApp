package controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import domain.Gerecht;
import domain.GerechtenService;
import domain.Person;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class GetGerechten extends AsyncRequestHandler{


    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {

        GerechtenService gerechtenService = getGerechtenService();
        ArrayList<Gerecht> gerechten = gerechtenService.getAll();

        //System.out.println("GetGerechten lengte arraylist: " + gerechten.size());
        return toJSON(gerechten);

    }

    public String toJSON (ArrayList<Gerecht> gerechten) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(gerechten);
    }
}
