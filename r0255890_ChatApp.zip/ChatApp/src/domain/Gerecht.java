package domain;

import java.time.LocalDate;

public class Gerecht {

    private String datum;
    private String naam;
    private int minuten;

    public Gerecht(String datum, String naam, int minuten){
        this.setDatum(datum);
        this.setNaam(naam);
        this.setMinuten(minuten);
    }

    protected void setDatum(String datum){
        if(datum == null){
            throw new IllegalArgumentException("Invalid Date!");
        }
        this.datum = datum;
    }

    protected void setNaam(String naam){
        if(naam == null ||naam.trim().isEmpty()){
            throw new IllegalArgumentException("Invalid Date!");
        }
        this.naam = naam;
    }

    protected void setMinuten(int minuten){
        if(minuten <= 0){
            throw new IllegalArgumentException("Invalid Date!");
        }
        this.minuten = minuten;
    }

    public String getDatum(){
        return this.datum;
    }

    public String getNaam(){
        return this.naam;
    }

    public int getMinuten(){
        return this.minuten;
    }

}
