package domain;

import db.GerechtRepository;
import db.GerechtRepositoryStub;

import java.util.ArrayList;

public class GerechtenService {
    private GerechtRepository gerechtRepository = new GerechtRepositoryStub();

    public GerechtenService() {
    }

    public void add(Gerecht gerecht) {
        getGerechtRepository().add(gerecht);
    }

    public void delete(Gerecht gerecht) {
        getGerechtRepository().delete(gerecht);
    }

    public ArrayList<Gerecht> getAll() {
        return getGerechtRepository().getAll();
    }

    private GerechtRepository getGerechtRepository(){
        return gerechtRepository;
    }


}
